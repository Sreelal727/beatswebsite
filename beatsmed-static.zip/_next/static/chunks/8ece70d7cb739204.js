__turbopack_load_page_chunks__("/_app", [
  "static/chunks/d01adca506ab55ea.js",
  "static/chunks/b5cbb0af8e8fb7ce.js",
  "static/chunks/turbopack-ce4734227449641f.js"
])
