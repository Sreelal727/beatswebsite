__turbopack_load_page_chunks__("/_error", [
  "static/chunks/c77ef85cd4dc733d.js",
  "static/chunks/b5cbb0af8e8fb7ce.js",
  "static/chunks/turbopack-c5ba597f5282842c.js"
])
